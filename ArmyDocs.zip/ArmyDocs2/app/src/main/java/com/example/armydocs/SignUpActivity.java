package com.example.armydocs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class SignUpActivity extends AppCompatActivity {
    public SignUpActivity(){

    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
    }

    public void signup(View v){
        EditText i = (EditText)findViewById(R.id.new_id);
        EditText p = (EditText)findViewById(R.id.new_password);
        EditText n = (EditText)findViewById(R.id.new_name);
        EditText s = (EditText)findViewById(R.id.new_srvno);
        EditText e = (EditText)findViewById(R.id.new_enlist_date);
        EditText d = (EditText)findViewById(R.id.new_discharge_date);
        EditText r = (EditText)findViewById(R.id.new_rank);
        EditText b = (EditText)findViewById(R.id.new_belong);

        //Toast.makeText(getApplicationContext(), "id:"+i.getText(), Toast.LENGTH_LONG).show();

        if(i.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), "아이디를 입력하세요.", Toast.LENGTH_LONG).show();
            i.requestFocus();
            return;
        }
        else if(p.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), "비밀번호를 입력하세요.", Toast.LENGTH_LONG).show();
            p.requestFocus();
            return;
        }
        else if(s.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), "군번을 입력하세요.", Toast.LENGTH_LONG).show();
            s.requestFocus();
            return;
        }
        else if(b.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), "소속부대를 입력하세요.", Toast.LENGTH_LONG).show();
            b.requestFocus();
            return;
        }
        else if(n.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), "이름을 입력하세요.", Toast.LENGTH_LONG).show();
            n.requestFocus();
            return;
        }
        else if(r.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), "계급을 입력하세요.", Toast.LENGTH_LONG).show();
            r.requestFocus();
            return;
        }
        else if(e.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), "입대일을 입력하세요.", Toast.LENGTH_LONG).show();
            e.requestFocus();
            return;
        }
        else if(d.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), "전역일을 입력하세요.", Toast.LENGTH_LONG).show();
            d.requestFocus();
            return;
        }
        else{
            startActivity(new Intent(SignUpActivity.this,HomeActivity.class));
        }
    }
}
