package com.example.armydocs;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    private void CheckFirstTime()
    {
        SharedPreferences   pref = getSharedPreferences("isFirst", Activity.MODE_PRIVATE);
        boolean             first = pref.getBoolean("isFirst", false);

        if (first == false)
        {
            SharedPreferences.Editor    editor = pref.edit();
            editor.putBoolean("isFirst", true);
            editor.commit();
        }
    }

    private void Initialize()
    {
        // 변수 초기화

        // 기능 초기화
        CheckFirstTime();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        Initialize();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewpager);

        ViewPager viewPager = findViewById(R.id.vp_pager1); //뷰 페이져
        MyPagerAdapter adapter = new MyPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapter);
    }
    public void MoveToLogin(View v){
       startActivity(new Intent(MainActivity.this,LoginActivity.class));
    }

    public void MoveToHome(View v){
        startActivity(new Intent(MainActivity.this,HomeActivity.class));
    }
    @Override
    public void onDestroy()
    {
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {}
}
