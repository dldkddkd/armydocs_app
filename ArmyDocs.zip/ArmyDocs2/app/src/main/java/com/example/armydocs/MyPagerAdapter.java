package com.example.armydocs;

import android.app.Activity;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.armydocs.Tutorial.TutorialFirstPage;
import com.example.armydocs.Tutorial.TutorialFourthPage;
import com.example.armydocs.Tutorial.TutorialSecondPage;
import com.example.armydocs.Tutorial.TutorialThirdPage;

import java.util.ArrayList;

public class MyPagerAdapter extends FragmentPagerAdapter {

    private ArrayList<Fragment> mainPage; //메인페이지의 프레그먼트 저장

    public MyPagerAdapter(FragmentManager fm) {
        super(fm);
        mainPage = new ArrayList<>();
        mainPage.add(new TutorialFirstPage());
        mainPage.add(new TutorialSecondPage());
        mainPage.add(new TutorialThirdPage());
        mainPage.add(new TutorialFourthPage());
    }

    @Override // 메인페이지의 포지션을 꺼낸다.
    public Fragment getItem(int position) { return mainPage.get(position); }

    @Override // 메인페이지의 총 크기
    public int getCount() {
        return mainPage.size();
    }

    public void onBackPressed(Activity activity) {
        activity.finish();
    }
}
