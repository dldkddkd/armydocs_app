package com.example.armydocs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    public LoginActivity(){

    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
    public void MoveToSignUp(View v){
        startActivity(new Intent(LoginActivity.this,SignUpActivity.class));
    }
    public void login(View v){
        EditText id = (EditText)findViewById(R.id.id);
        EditText pw = (EditText)findViewById(R.id.password);

        if(id.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), "아이디를 입력하세요.", Toast.LENGTH_LONG).show();
            id.requestFocus();
            return;
        }
        else if(pw.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), "비밀번호를 입력하세요.", Toast.LENGTH_LONG).show();
            pw.requestFocus();
            return;
        }
        else if(!id.getText().toString().equals("dldkddkd") || !pw.getText().toString().equals("sejong2016@")){
            Toast.makeText(getApplicationContext(), "아이디/비밀번호가 틀립니다.", Toast.LENGTH_LONG).show();
            System.out.println("id:"+id.getText().toString()+"| pw:"+pw.getText().toString());
            return;
        }
        else{
            startActivity(new Intent(LoginActivity.this,HomeActivity.class));
        }
    }
}
