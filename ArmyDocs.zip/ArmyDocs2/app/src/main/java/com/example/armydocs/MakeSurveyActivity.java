package com.example.armydocs;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class MakeSurveyActivity extends AppCompatActivity {
    public static Activity makesurveyActivity;
    public String[] fileArray = {"Android", "iPhone", "WindowMobile","Blackberry", "WebOS", "Ubuntu", "Windows10", "Mac OS"};
    public MakeSurveyActivity() {
        // Required empty public constructor
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        makesurveyActivity = this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);
        ImageView backbutton = (ImageView)findViewById(R.id.back_button);
        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                makesurveyActivity.finish();
            }
        });

    }

    public void makeNewQuestion(){
        ListView surveyList = (ListView)findViewById(R.id.SurveyList);
        ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.activity_survey, fileArray);
        surveyList.setAdapter(adapter);

    }

    public void makeNewOption(){

    }
}